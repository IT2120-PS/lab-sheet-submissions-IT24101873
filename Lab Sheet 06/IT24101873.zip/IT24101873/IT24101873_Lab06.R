setwd("C:\\Users\\IT24101873\\Desktop\\IT24101873")
# what is the distibution of X?
n <- 50
p <- 0.85

# what is the probability that at least 47 students passed the test?
prob_atleast47 <- pbinom(46, size = n, prob = p, lower.tail = FALSE)
prob_atleast47


# A call center receives an average of 12 customers calls per hour
#what is the random vaiable of (X) fir the problem
# X = number of calls received in 1 hour

# what is the distrbution of X
lambda <- 12

# What is the probability that exactly 15 cals are received in an hour
prob_15 <-dpois(15, lambda =  lambda)
prob_15

