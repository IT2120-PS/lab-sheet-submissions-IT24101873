setwd('C:\\Users\\IT24101873\\Desktop\\IT24101873_lab10')
#snack_types <- c("A", "B", "C", "D")
snack_types <- c("A", "B", "C", "D")
observed <- c(120,95,85,100)

total <- sum(observed)
expected <- rep(total/ length(observed), length(observed))

#dispaly data 
data.frame(Snack_type = snack_types, Observed = observed, Expected = expected)
test_result <- chisq.test(x = observed ,p = rep(0.25, 4))

#print 
test_result

